import random
from itertools import combinations as combo
import matplotlib.pyplot as plt
from PIL import Image
from threading import Timer

def lprint(lijst, print_att=None):
    #Handig om elk element van een lijst per stuk te printen, elk op een nieuwe regel
    #Met elementen in de lijst ook een lijst, kan je die nested lijst een regel lang maken met print_att
    if print_att == None:
        for elem in lijst:
            print(elem)
    else:
        for elem in lijst:
            print(eval("elem." + print_att),end="")
        print("")    
             
class Kaart(object):
    #Een Kaart Class, om de kaarten te maken die we gebruiken in het spel, handige shorthand
    def __init__(self,eig,d=4,f=3):
        self.eig = eig      #De Lijst met daadwerkelijke eigenschappen (bijv [0,2,1,0])
        self.dim = d        #De hoeveelheid dimensies,       standaard d=4
        self.free = f       #De hoeveelheid vrijheidsgraden, standaard f=3
    
    def __eq__(self,other):
        #Twee kaarten zijn aan elkaar gelijk als ze dezelfde eigenschappen hebben
        #(waardoor ze ook dezelfde dimensie hebben), en dezelfde hoeveelheid vrijheidsgraden
        return self.eig == other.eig and self.free == other.free
    
    def __str__(self):
        #Als we een Kaart 'printen' wordt dit laten zien, fijne weergave
        return "SETKaart; {}".format(self.eig)
    
    def __repr__(self):
        #Wanneer een aangeroepte kaart geprint wordt is dit de manier; onbetwistbaar
        return "{} (f={})".format(self.eig,self.free)
    
    def Vorm(self):
        #Geeft ook voor dim<4 de correcte syntax om de naam van het plaatje aan te roepen
        if self.dim == 4:
            return self.eig
        elif self.dim < 4:
            rest = 4-self.dim
            return [*[0]*rest,*self.eig]
        else:
            raise NotImplementedError


class SET(object):
    """ De daadwerkelijke klasse waarmee SET gespeeld wordt, maakt zijn eigen instande variabelen
        die ervoor zorgen dat, samen met de eigen methodes, het spel in zijn geheelheid gespeeld
        kan worden, door middel van de class."""
    def __init__(self,d=4,f=3):
        """ 1: Maakt een lijst met alle mogelijke kaarten, dat als de trekstapel zal fungeren
            2: Deze trekstapel wordt geschud, en er worden kaarten getrokken om het initiele
               speelveld te maken, die op tafel komen te liggen in een mooie grid
            3: Zoekt vervolgens alle mogelijke SETs die op tafel liggen, en slaat die op in een lijst
               om later te raadplegen; roept de findsets functie aan
            4: Maakt dictionaries aan voor de speler en de computer, die bijhouden hoeveel rondes
               elk heeft gewonnen, en welke kaarten ze hebben gebruikt om hun SETs te vormen"""
        self.dim  = d   #De hoeveelheid dimensies,       standaard d=4      De regel hieronder
        self.free = f   #De hoeveelheid vrijheidsgraden, standaard f=3      is Stap 1
        self.deck     = [Kaart([(i//f**k)%f for k in range(d)],d,f) for i in range(f**d)]
        random.shuffle(self.deck)       #Dit is samen met de volgende regel Stap 2
        self.tafel    = [[self.deck.pop(0) for i in range(f)] for j in range(d)] #0 want de bovenste kaart
        self.findsets()                 #Stap 3; noemt de lijst self.sets
        self.Player   = {"Score":0,"Cards":[],"Gamewins":0} #Stap 4: begin met score 0, zonder kaarten
        self.Computer = {"Score":0,"Cards":[],"Gamewins":0} #en voor de computer hetzelfde verhaal
    
    def findsets(self):
        """ De findsets functie wordt gebruikt om alle SETs te vinden die op tafel liggen, en slaat
            die op in een lijst, zodat we die kunnen raadplegen; roept isset aan"""
        self.sets = []     #Hiermee wordt er voor gezorgd dat er geen oude sets blijven staan
        #Check voor alle mogelijk combinaties van kaarten op tafel of het een set is       
        for c in combo([kaart for row in self.tafel for kaart in row],self.free):
            if self.isset(c):           #En als het een set is;
                self.sets.append([*c])  #voeg het dan toe aan de lijst
                
    def isset(self,Kaarten):               
        """ De isset functie wordt gebruikt om te checken of een combinatie van een willekeurig aantal
            kaarten een SET is, in praktijk zijn dit altijd f aantal kaarten"""
        if len(Kaarten) == self.free:
            return all((len(set(Freedom)) == 1 or len(set(Freedom)) == self.free
                        for Freedom in zip(*[Kaart.eig for Kaart in Kaarten])))
        else:
            return False
        
    def showtable(self,Showscore=True):
        """ Maakt een figuur met grafieken (subplots), met elk grafiekje een plaatje van een kaart,
            in een grid van f breed en d lang, kan korter als het deck leeg is geworden"""
        if self.dim <= 4 and self.free <= 3:
            if not self.tafel:
                plt.plot()
                plt.axis("off")
                plt.show()
                return
            r = len(self.tafel) #Bepaal hoeveel rijen er dus daadwerkelijk zijn
            c = self.free       #De breedte van elke rij is onveranderlijk
                                #Maak vervolgens het figuur met de juiste hoeveelheid subplots en grootte
            fig,ax = plt.subplots(r,c,figsize=(3*c,3*r))
                                #Importeer de namen van de files die corresponderen met de kaarten
            files = [["Plaatjes\Kaart{}.png".format(
                        self.tafel[i][j].Vorm()) for i in range(r)] for j in range(c)]
            for i in range(r):                  #Stop vervolgens voor elke rij
                for j in range(c):              #En voor elke kolom
                    if r > 1:                   #Het plaatje van die kaart op de juiste plek
                        ax[i][j].imshow(Image.open(files[j][i]))
                        ax[i][j].axis("off")    #Zonder de labels die normaal bij een grafiek horen
                    else:
                        ax[j].imshow(Image.open(files[j][i]))
                        ax[j].axis("off")
            plt.show()                          #Laat de grafiek ook zien 
        else:
            for i in range(len(self.tafel)):
                lprint(self.tafel[i],"eig")
        if Showscore:
            print("Score: {} vs {}".format(self.Player["Score"],self.Computer["Score"]))
    
    """ Vanaf hier zijn de daadwerkelijke methodes om het spel te spelen, alles hiervoor was nog ter
        ter ondersteuning van de __init__ functie"""
    
    def Playround(self, time=30, n=1):
        """ Gebruik deze functie om een 'n' aantal rondes te spelen, met userinput nodig om aan te geven
            welke SET de Player denkt dat er is, if any."""
        def Timeout():
            self.timeup = True                                  #Geeft aan dat de tijd op is.
            print("Your time is up; press Enter to continue")   #laat de speler weten dat de tijd op is
        for i in range(n):
            if self.deck or self.sets:
                self.showtable()
                self.timeup = False                             #Zet de waarde van timeup terug op False
                timer = Timer(time,Timeout)                     #Maakt een thread die na time seconden de
                timer.start()                                   #timeout functie uitgevoert en start deze
                Input = input("Input a SET: ")
                SETC = self.GetCoords(Input)
                SETL = self.LoctoCoord(Input)
                while (SETC == False and SETL == False) and self.timeup == False:
                    Input = input("Try again: ")
                    SETC = self.GetCoords(Input)
                    SETL = self.LoctoCoord(Input)
                if self.timeup:                                 #Als er een timeout is:
                    self.Endround("",Timeup=True)               #Eindig de ronde met een timeout = True
                else:                                           #Zo niet:
                    timer.cancel()                              #Stop de (aanroep van de) timeoutfunctie
                    if SETC == False:                           #Eindig de ronde met de ingevoerde SET
                        self.Endround(SETL)
                    else:
                        self.Endround(SETC)
            else:
                print("You cannot play another round; the game has already ended.")
                print("Try restarting...")
                break
    
    def GetCoords(self,Input):
        if isinstance(Input,str):
            if Input == "":
                return None
            sliced = Input.split()
            if len(sliced) == 1:
                return False
            Coords = []
            for i in range(len(sliced)):
                if self.dim > 10 or self.free > 10:
                    sliced[i] = sliced[i].split('.')
                #Met input "00 10 20" is het de bovenste rij, en "11 12 13" de onderste drie
                Coords.append([int(sliced[i][1]),int(sliced[i][0])])  #kaarten in het midden
            Validinput = True
            if not (all(Coords[i][0] in list(range(self.dim)) for i in range(len(Coords))) and all(
                       Coords[j][1] in list(range(self.free)) for j in range(len(Coords)))):
                print("Invalid Input; Coordinates out of bounds")
                Validinput = False
            if len(Coords) != self.free:
                print("Invalid Input; Set wrong size")
                Validinput = False
            if len(Coords) != len(set([tuple(Loc) for Loc in Coords])):
                print("Invalid Input; Duplicate Cards")
                Validinput = False
            if Validinput:
                return Coords
            else:
                return False
        else:
            Coords = []
            for kaart in Input:
                Index = [kaart for row in self.tafel for kaart in row].index(kaart)
                Coords.append([Index//self.free,Index%self.free])
            return Coords
    
    def LoctoCoord(self,string):    #Kan alleen bij F=3, D<=4
        elem = len(string)
        Validinput = True
        if string == "":
            return None
        elif len(string.split()) > 1:
            return False
        else:
            if elem != len(set(string)):
                print("Invalid User Input; Duplicate Cards")
                Validinput = False
            if elem != 3:
                print("Invalid User Input; Set wrong size")
                Validinput = False
            if len(self.tafel)==4 and not all(i in "123qweasdzxc" for i in string):
                print("Invalid User Input; Incorrect Character(s)")
                Validinput = False
            elif len(self.tafel) == 3 and not all(i in "123qweasd" for i in string):
                print("Invalid User Input; Incorrect Character(s)")
                Validinput = False
            elif len(self.tafel) == 2 and not all(i in "123qwe" for i in string):
                print("Invalid User Input; Incorrect Character(s)")
                Validinput = False
            elif len(self.tafel) == 1 and not all(i in "123" for i in string):
                Validinput = False 
            if Validinput:
                Coor = {"1": [0,0], "2": [0,1], "3": [0,2], "q": [1,0], "w": [1,1], "e": [1,2],
                        "a": [2,0], "s": [2,1], "d": [2,2], "z": [3,0], "x": [3,1], "c": [3,2]}
                Lijst = [Coor[string[0]],Coor[string[1]],Coor[string[2]]]
                return Lijst
            else:
                return Validinput
    
    def Endround(self,Coords,Timeup=False):
        
        def SETfound(Coords,winner):
            eval("self." + winner)["Score"] += 1
            eval("self." + winner)["Cards"].extend([self.tafel[Loc[0]][Loc[1]] for Loc in Coords])
            if winner == "Computer":
                print("Computer wins the round with SET;",Coords,end=" ")
            else:
                print("You win the round.",end=" ")
            print("New Score: Player {} vs Computer {}".format(self.Player["Score"],self.Computer["Score"]))
            self.Redraw(Coords)
            
        if Timeup:         #If the time is up, either redraw of computerwin
            print("Time is up.",end=" ")
            if self.sets:   #If there are SETs available, computer wins the round
                SETfound(self.GetCoords(self.sets[0]),"Computer")
            else:           #Otherwise, redraw the top cards
                self.Redraw()
        elif Coords == None:
            #If the player input is that there is no SET available
            if self.sets:       #And there IS one, computer wins the round
                print("Wrong: There is a set;",end=" ")
                SETfound(self.GetCoords(self.sets[0]),"Computer")
            else:               #Otherwise, redraw the top cards
                print("Correct:",end=" ")
                self.Redraw()
        else:
            #If the player gives a Set: *valid* coordinates for the *right amount* of *different* cards
            Cards = []
            for Loc in Coords:
                Cards.append(self.tafel[Loc[0]][Loc[1]])
            if self.isset(Cards):   #Check if those cards actually form a SET
                print("Well done!",end=" ")
                SETfound(Coords,"Player")
            else:                   #The Cards the player gave are no SET, just a Set
                print("These cards are not a SET.",end=" ")
                if self.sets:       #If there are actual SETS available, the computer wins the round
                    SETfound(self.GetCoords(self.sets[0]),"Computer")
                else:               #Redraw if no SETs present, even if the player input was otherwise
                    self.Redraw()
    
    def Redraw(self,Coords=None):
        """ Called with Coords == None only if there are NO SETs
            otherwise the entered coordinates is an already validated SET."""
        def Rearrange(Coords=[]):
            table = [kaart for row in self.tafel for kaart in row]
            for Loc in Coords:
                table.remove(self.tafel[Loc[0]][Loc[1]])
            newrows = len(table)//self.free    
            self.tafel = [[table.pop(0) for i in range(self.free)] for j in range(newrows)]
            
        if not Coords:         #If there are no Coordinates given; there is no SET
            print("There is no SET,",end=" ")
            if self.deck:       #If the deck is not empty; redraw the top cards
                if (len(self.deck)+self.dim*self.free) < self.dim**self.free/self.free:
                    remcards = self.deck
                    for row in self.tafel:
                        remcards.extend(row)
                    if not self.findset(remcards):
                        print("not even if you combine all remaining cards.")
                        self.Endgame()
                        return
                    else:
                        print("redrawing the top {} cards".format(self.free))
                        Placeholder = [self.tafel[0].pop() for i in range(self.free)]
                        for i in range(self.free):
                            self.tafel[0].append(self.deck.pop(0))
                        self.deck.extend([Placeholder.pop(0) for i in range(self.free)])
                        random.shuffle(self.deck)
                else:        
                    print("redrawing the top {} cards".format(self.free))
                    Placeholder = [self.tafel[0].pop() for i in range(self.free)]
                    for i in range(self.free):
                            self.tafel[0].append(self.deck.pop(0))
                    self.deck.extend([Placeholder.pop(0) for i in range(self.free)])
                    random.shuffle(self.deck)
            else:               #If the deck is also empty, then the game is over.
                print("and the Deck is empty.")
                self.Endgame()
                return
        elif self.deck:         #Coordinates are given of the cards to be replaced
            for Loc in Coords:
                self.tafel[Loc[0]][Loc[1]] = self.deck.pop(0)
        else:                   #If the deck is empty, remove the given Set and rearrange
            Rearrange(Coords)
        self.findsets()
        if not (self.sets or self.deck):
            print("There is no SET, and the Deck is empty.")
            Rearrange()
            self.Endgame()

    def findset(self,List):
        for c in combo(List,self.free):
            if self.isset(c):
                return c
        return False

    def Endgame(self):
        print("\n","          ~~Game Over~~","\n")
        print("Final Score: Player {} vs Computer {}"
              .format(self.Player["Score"],self.Computer["Score"]))
        if self.Player["Score"] > self.Computer["Score"]:
            print("Congratulations, you have won! Let's play another time!")
            self.Player["Gamewins"] += 1
        elif self.Player["Score"] < self.Computer["Score"]:
            print("Too bad, you lost to the Computer, better luck next time.")
            self.Computer["Gamewins"] += 1
        else:
            print("The Game ended in a tie, maybe you'll win next time?")
        print("")
    
    def Play(self,time = 30, autowin = False, Aardsmormeldier = False):
        if autowin: #This lets the player win an automated game
            while self.deck or self.sets:
                if Game.sets:
                    Game.Endround(Game.GetCoords(Game.sets[0]))
                else:
                    Game.Endround(None)
            print("Try not to cheat the next time.")            #For you cheeky/cheaty bastards...
        elif Aardsmormeldier:
            while self.deck or self.sets:
                Game.Endround(None)
            print("You're making it too easy.")               #There are easier ways to admit defeat...
        else:
            while self.deck or self.sets:
                self.Playround(time = time)
        
    def Reset(self):
        Diff = self.Player["Gamewins"]-self.Computer["Gamewins"]
        print("\n","Reinitializing Game,",end=" ")
        if Diff > 0:
            print("Player is leading by {} game".format(Diff),end="")
            if Diff > 1:
                print("s")
            else:
                print("")
        elif Diff < 0:
            print("Computer is leading by {} game".format(-Diff),end="")
            if Diff < -1:
                print("s")
            else:
                print("")
        else:
            print("the match is currently tied")
        for i in range(len(self.tafel)):
            for X in range(len(self.tafel[0])):
                self.deck.append(self.tafel[0].pop())
            self.tafel.remove(self.tafel[0])
        self.deck.extend(self.Player["Cards"])
        self.deck.extend(self.Computer["Cards"])
        random.shuffle(self.deck)
        self.Player["Score"] = 0
        self.Player["Cards"] = []
        self.Computer["Score"] = 0
        self.Computer["Cards"] = []
        self.tafel = [[self.deck.pop(0) for i in range(self.free)] for j in range(self.dim)]
        print("\n" + "Good luck again this tme.")
        
print("Welcome to the game of SET. Good luck and have fun.")

f = int(input("How many degrees of freedom do you want to play with? (Normal is 3) "))
d = int(input("How many dimensions do you want to play with? (Normal is 4) "))
t = int(input("How many seconds till a timeout? "))
"""
d = 4
f = 3
t = 30
"""
#Restart = "YES"
#while Restart == "YES":
Game = SET(d,f)
Game.Play(time = t)
"""
    while not (Restart == "YES" or Restart == "NO"):
        Restart = input("I don't understand, can you clarify? I have lots of time. ").capitalize()
    Restart = input("Would you like to play again? (Yes or No) ").capitalize()
    if Restart == "YES":
        print("Welcome back! Let me reshuffle the cards for you.")
        Game.Reset()
    elif Restart == "NO":
        print("Too bad, peanut butter (jelly time).")
"""
    


"""
#Use this code to have the computer play an automated game
while Game.deck:
    #Game.Endround(None)  #This lets the computer win the automated game
    if Game.sets:         #This lets the player win the automated game
        Game.Endround(Game.GetCoords(Game.sets[0]))
    else:
        Game.Endround(None)
while Game.sets:
    Game.Endround(None)
Game.Restart()
while Game.deck:
    #Game.Endround(None)  #This lets the computer win the automated game
    if Game.sets:         #This lets the player win the automated game
        Game.Endround(Game.GetCoords(Game.sets[0]))
    else:
        Game.Endround(None)
while Game.sets:
    Game.Endround(None)
Game.Restart()
while Game.deck:
    #Game.Endround(None)  #This lets the computer win the automated game
    if Game.sets:         #This lets the player win the automated game
        Game.Endround(Game.GetCoords(Game.sets[0]))
    else:
        Game.Endround(None)
while Game.sets:
    Game.Playround()
Game.Restart()
"""