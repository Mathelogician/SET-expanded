# -*- coding: utf-8 -*-
"""
Created on Tue Jun 11 15:00:25 2019

@author: anouk
"""

import random
from itertools import combinations as combo
import matplotlib.pyplot as plt
from PIL import Image
from threading import Timer

def lprint(lijst, print_att=None):
    #Handig om elk element van een lijst per stuk te printen, elk op een nieuwe regel
    #Met elementen in de lijst ook een lijst, kan je die nested lijst een regel lang maken met print_att
    if print_att == None:
        for elem in lijst:
            print(elem)
    else:
        for elem in lijst:
            print(eval("elem." + print_att),end="")
        print("")    
             
class Kaart(object):
    #Een Kaart Class, om de kaarten te maken die we gebruiken in het spel, handige shorthand
    def __init__(self,eig,d=4,f=3):
        self.eig = eig      #De Lijst met daadwerkelijke eigenschappen (bijv [0,2,1,0])
        self.dim = d        #De hoeveelheid dimensies,       standaard d=4
        self.free = f       #De hoeveelheid vrijheidsgraden, standaard f=3
    
    def __eq__(self,other):
        #Twee kaarten zijn aan elkaar gelijk als ze dezelfde eigenschappen hebben
        #(waardoor ze ook dezelfde dimensie hebben), en dezelfde hoeveelheid vrijheidsgraden
        if isinstance(other,Kaart):
            return self.eig == other.eig and self.free == other.free
        elif isinstance(other,list):        #Soms maken we een lijst van eigenschappen die een kaart
            return self.eig == other        #voorstelt en zo kunnen die vergeleken worden met kaarten
    
    def __str__(self):
        #Als we een Kaart 'printen' wordt dit laten zien, fijne weergave
        return "SETKaart; {}".format(self.eig)
    
    def __repr__(self):
        #Wanneer een aangeroepte kaart geprint wordt is dit de manier; onbetwistbaar
        return "{} (f={})".format(self.eig,self.free)
    
    def Vorm(self):
        if isinstance(self,Kaart):
            Eigext = []
            for i in range(len(self.eig)):
                Eigext.append(self.eig[i])
            for i in range(len(self.eig),4):
                Eigext.append(0)
            return(Eigext)
        else:
            return(self)
            
        
class SET(object):
    """ De daadwerkelijke klasse waarmee SET gespeeld wordt, maakt zijn eigen instande variabelen
        die ervoor zorgen dat, samen met de eigen methodes, het spel in zijn geheelheid gespeeld
        kan worden, door middel van de class."""
    def __init__(self,d=4,f=3,n=1):
        """ 1: Maakt een lijst met alle mogelijke kaarten, dat als de trekstapel zal fungeren
            2: Deze trekstapel wordt geschud, en er worden kaarten getrokken om het initiele
               speelveld te maken, die op tafel komen te liggen in een mooie grid
            3: Zoekt vervolgens alle mogelijke SETs die op tafel liggen, en slaat die op in een lijst
               om later te raadplegen; roept de findsets functie aan
            4: Maakt dictionaries aan voor de speler en de computer, die bijhouden hoeveel rondes
               elk heeft gewonnen, en welke kaarten ze hebben gebruikt om hun SETs te vormen
            5: Als laatste geeft hij een plaatje van de beginsituatie op tafel"""
        self.dim  = d   #De hoeveelheid dimensies,       standaard d=4      De regel
        self.free = f   #De hoeveelheid vrijheidsgraden, standaard f=3      hieronder
        self.n = n      #Hoeveel n-SET we spelen,        standaard 1        is Stap 1
        self.deck     = [Kaart([(i//f**k)%f for k in range(d)],d,f) for i in range(f**d)]
        random.shuffle(self.deck)       #Dit is samen met de volgende regel Stap 2
        self.tafel    = [[self.deck.pop(0) for i in range(f)] for j in range(d)] #0 want de bovenste kaart
        self.findnsets()                 #Stap 3; noemt de lijst self.sets
        self.Player   = {"Score" : 0, "Cards" : [], "Gamewins" : 0} #Stap 4: begin met score 0
        self.Computer = {"Score" : 0, "Cards" : [], "Gamewins" : 0} #en voor de computer hetzelfde verhaal
        self.showtable(False)           #Stap 5
    
    def findnsets(self):
        #Returnt de kaarten die een set vormen bij n=0 en n=1, anders returnt die de 
        #indices van de kaarten die een set vormen
        self.sets = []                   #Hiermee wordt er voor gezorgd dat er geen oude sets blijven staan
        if self.n==0:                         #0-sets zijn F-1 dezelfde kaarten, dus dit kan niet bij F>2.
            if self.free == 2:
                self.sets = [kaart for row in self.tafel for kaart in row]
        elif self.n==1:
             #Check voor alle mogelijke combinaties van kaarten op tafel of het een set is       
             for c in combo([kaart for row in self.tafel for kaart in row],self.free):
                 if self.isnset(c):          #En als het een set is;
                     self.sets.append([*c])  #voeg het dan toe aan de lijst
        else:
            if self.n%2 == 1:
                begin = 1
            else:
                begin = 0
            Kaarten = []
            Tafel = [kaart for row in self.tafel for kaart in row]
            while Tafel[-1] == Kaart([-1]*self.free,self.dim,self.free):
                Tafel.pop(-1)
            for i in range(len(Tafel)):
                Kaarten.append([Tafel[i],str(i)])
            Basis = self.Expand(Kaarten,self.n)
            S = self.Setgrootte()
            Combinaties = combo(Basis,self.free-1+begin)
            for c in Combinaties:
                Lijst   = [duo[0] for duo in c]
                Indices = [duo[1] for duo in c]
                if self.isnset(Lijst,begin):
                    Cards = []
                    for Index in Indices:
                        Card = Index.split(',')
                        Cards.extend(Card)
                    Cards = [int(i) for i in Cards]
                    if len(set(Cards)) == S:
                        Set = [Tafel[Card] for Card in Cards]
                        self.sets.append(Set)
    
    def isnset(self,Kaarten,n):
        if n == 0:                      #Een 0-set is een verzameling identieke kaarten
            if len(Kaarten) == self.Setgrootte(0):   
                all(Kaarten[i-1] == Kaarten[i] for i in range(len(Kaarten)))
            else:
                return False
        elif n == 1:                    #een 1-SET is het normale geval
            if len(Kaarten) == self.Setgrootte(1):
                return all((len(set(Freedom)) == 1 or len(set(Freedom)) == self.free
                            for Freedom in zip(*[Kaart.eig for Kaart in Kaarten])))
            else:
                return False
        else:   #Gaat de 'missende' kaarten (otherkaart) bepalen voor elk f-1 tal ingevoerde kaarten
            if len(Kaarten) == self.Setgrootte(n): #Die in volgorde zijn ingevoerd
                Others = []
                for i in range(0,len(Kaarten),self.free-1): #Voor elke verzameling F-1 kaarten
                    Deelset = []                    #Maakt hij de verzameling apart
                    for j in range(self.free-1):    #Loopt over de rest van de F-1 kaarten
                        Deelset.append(Kaarten[i+j])
                    Other = self.Missing(Deelset)   #Bekijkt welke kaart mist (als mogelijk)
                    if Other:                       #Als het een kaart is (dus waar)
                        Others.append(Other)
                    else: #Als other false is, kan geen set gevormd worden, dus is de hele poging fout
                        return False
                return self.isnset(Others,n-2)      #Check of de missende kaarten een n-2 set vormen
            else:
                return False
    
    def Setgrootte(self,n = 1): #Tussenfunctie die de grootte van een set bepaald uit n en self.free
        if n == 0:
            return self.free-1 
        elif n == 1:
            return self.free
        else:
            return (self.free-1)*self.Setgrootte(n-2)

    def Missing(self,Kaarten):                
        #Bepaald voor een lijst van f-1 kaarten de kaart die er een set van maakt. 
        #Returnt False als het onmogelijk is.     
        Otherkaart = []                 #Maak de lijst met eigenschappen aan
        if all(isinstance(Kaarten[i],Kaart) for i in range(len(Kaarten))):
            for i in range(self.dim):   #Voor elke eigenschap check of het gelijk of verschillend moet zijn
                if all(Kaarten[j].eig[i] == Kaarten[j+1].eig[i] for j in range(len(Kaarten)-1)):
                    Otherkaart.append(Kaarten[0].eig[i])
                    #Als ze allemaal hetzelfde zijn, zal de laatste kaart dat ook moeten zijn
                else:                                   #Als ze allemaal verschillend moeten zijn
                    Total = sum([i for i in range(self.free)])
                    Options = [Kaarten[j].eig[i] for j in range(self.free-1)]
                    Last = Total-sum(Options)
                    if Last in Options:
                        return False
                    else:
                        Otherkaart.append(Last)
            return Kaart(Otherkaart,self.dim,self.free)
        else:
            return False
                                
    def Expand(self,Kaarten,n): 
        #Heeft als invoer een lijst met daarin elementen vd vorm [Kaart,[indexen]]
        #En geeft als uitvoer eenzelfde lijst, maar dan moet daarin een n-2 set worden gezocht.
        #Met de indices is later terug te vinden welke kaarten de set vormen
        if n<=1:
            return Kaarten
        else:
            Lijst = []
            Combinaties = combo(Kaarten,self.free-1)
            for c in Combinaties:
                Combi = []
                Index = ''
                for i in range(len(c)-1):
                    Combi.append(c[i][0])
                    Index += c[i][1] + ','
                Combi.append(c[-1][0])
                Index += c[-1][1]
                Other = self.Missing(Combi)                 #Vind de missende kaart
                if Other:                                   #Als het een geldige kaart is
                    Lijst.append([Other,Index])
            return self.Expand(Lijst,n-2)
        
    def showtable(self,Showscore=True):
        """ Maakt een figuur met grafieken (subplots), met elk grafiekje een plaatje van een kaart,
            in een grid van f breed en d lang, kan korter als het deck leeg is geworden"""
        if self.dim <= 4 and self.free <= 3:
            if not self.tafel:
                plt.plot()
                plt.axis("off")
                plt.show()
                return
            r = len(self.tafel) #Bepaal hoeveel rijen er daadwerkelijk zijn
            c = self.free       #De breedte van elke rij is onveranderlijk
                                #Maak vervolgens het figuur met de juiste hoeveelheid subplots en grootte
            fig,ax = plt.subplots(r,c,figsize=(3*c,3*r))
                                #Importeer de namen van de files die corresponderen met de kaarten
            files = [["Plaatjes\Kaart{}.png".format(
                        self.tafel[i][j].Vorm()) for i in range(r)] for j in range(c)]
            for i in range(r):                              #Stop vervolgens voor elke rij
                for j in range(c):                          #En voor elke kolom
                    if r>1:
                        ax[i][j].imshow(Image.open(files[j][i]))#Het plaatje van die kaart op de juiste plek
                        ax[i][j].axis("off")                    #Zonder de labels van een normaal grafiek
                    else:
                        ax[i].imshow(Image.open(files[j][i]))#Het plaatje van die kaart op de juiste plek
                        ax[i].axis("off")                    #Zonder de labels van een normaal grafiek
                    #Pauzeer vervolgens even, zodat het figuur dat in de editor zit 
            plt.show()  #daadwerkelijk afgebeeld wordt, zonder ergens anders op te wachten.
        else:
            for i in range(len(self.tafel)):
                lprint(self.tafel[i],"eig")
        print("# of SET's:",len(self.sets))
        if Showscore:
            print("Score: {} vs {}".format(self.Player["Score"],self.Computer["Score"]))
    
    """ Vanaf hier zijn de daadwerkelijke methodes om het spel te spelen, alles hiervoor was nog ter
        ter ondersteuning van de __init__ functie"""

    
    def Playround(self, time=30, n=1):
        """ Gebruik deze functie om een 'n' aantal rondes te spelen, met userinput nodig om aan te geven
            welke SET de Player denkt dat er is, if any."""
        def Timeout():
            self.timeup = True                                  #Geeft aan dat de tijd op is.
            print("Your time is up; press Enter to continue")   #laat de speler weten dat de tijd op is
        for i in range(n):
            if self.deck or self.sets:
                self.showtable()
                self.timeup = False                             #Zet de waarde van timeup terug op False
                timer = Timer(time,Timeout)                     #Maakt een thread die na time seconden de
                timer.start()                                   #timeout functie uitgevoert en start deze
                Input = input("Input a SET: ")
                SETC = self.GetCoords(Input)
                SETL = self.LoctoCoord(Input)
                while (SETC == False and SETL == False) and self.timeup == False:
                    Input = input("Try again: ")
                    SETC = self.GetCoords(Input)
                    SETL = self.LoctoCoord(Input)
                if self.timeup:                                 #Als er een timeout is:
                    self.Endround("",Timeup=True)               #Eindig de ronde met een timeout = True
                else:                                           #Zo niet:
                    timer.cancel()                              #Stop de (aanroep van de) timeoutfunctie
                    if SETC == False:                           #Eindig de ronde met de ingevoerde SET
                        self.Endround(SETL)
                    else:
                        self.Endround(SETC)
            else:
                print("You cannot play another round; the game has already ended.")
                print("Try restarting...")
                break
    
    def GetCoords(self,Input):
        if isinstance(Input,str):
            if Input == " ":
                return None
            if Input == "t": #De invoer bij een timeout
                return None #Zorgt ervoor dat uit de input while-lus wordt gesprongen
            sliced = Input.split()
            if len(sliced) == 1:
                return False
            Coords = []
            for i in range(len(sliced)):
                #Met input "00 10 20" is het de bovenste rij, en "11 12 13" de onderste drie
                Coords.append([int(sliced[i][1]),int(sliced[i][0])])  #kaarten in het midden
            Validinput = True
            if not (all(Coords[i][0] in list(range(len(self.tafel))) for i in range(len(Coords))) and all(
                       Coords[j][1] in list(range(len(self.tafel[0]))) for j in range(len(Coords)))):
                print("Invalid Input; Coordinates out of bounds")
                Validinput = False
            if len(Coords) != self.Setgrootte():
                print("Invalid Input; Set wrong size")
                Validinput = False
            if len(Coords) != len(set([tuple(Loc) for Loc in Coords])):
                print("Invalid Input; Duplicate Cards")
                Validinput = False
            if Validinput:
                return Coords
            else:
                return False
        else:
            Coords = []
            for kaart in Input:
                Index = [kaart for row in self.tafel for kaart in row].index(kaart)
                Coords.append([Index//self.free,Index%self.free])
            return Coords
    
    def LoctoCoord(self,string):
        elem = len(string)
        Validinput = True
        if string == "":
            return None
        if string == "t": #input bij timeout
            return None #zorgt ervoor dat uit de input while-lus wordt gesprongen
        else:
            if elem != len(set(string)):
                print("Invalid User Input; Duplicate Cards")
                Validinput = False
            if elem != self.Setgrootte(self.n):
                print("Invalid User Input; Set wrong size")
                Validinput = False
            if len(self.tafel)==4 and not all(i in "123qweasdzxc" for i in string):
                print("Invalid User Input; Incorrect Character(s)")
                Validinput = False
            elif len(self.tafel) == 3 and not all(i in "123qweasd" for i in string):
                print("Invalid User Input; Incorrect Character(s)")
                Validinput = False
            elif len(self.tafel) == 2 and not all(i in "123qwe" for i in string):
                print("Invalid User Input; Incorrect Character(s)")
                Validinput = False
            elif len(self.tafel) == 1 and not all(i in "123" for i in string):
                Validinput = False 
            if Validinput:
                Coor = { "1": [0,0], "2": [0,1], "3": [0,2], "q": [1,0], "w": [1,1], "e": [1,2],
                         "a": [2,0], "s": [2,1], "d": [2,2], "z": [3,0], "x": [3,1], "c": [3,2]}
                Lijst = []
                for i in range(self.Setgrootte(self.n)):
                    Lijst.append(Coor[string[i]])
                return(Lijst)
            else:
                return Validinput
    
    def Endround(self,Coords,Timeout=False):
        
        def SETfound(Coords,winner):
            eval("self." + winner)["Score"] += 1
            eval("self." + winner)["Cards"].extend([self.tafel[int(Loc[0])][int(Loc[1])] for Loc in Coords])
            if winner == "Computer":
                print("Computer wins the round, with SET", Coords,end=" ")
            else:
                print("You win the round.",end=" ")
            print("New Score: Player {} vs Computer {}".format(self.Player["Score"],self.Computer["Score"]))
            self.Redraw(Coords)
            
        if Timeout:         #If the time is up, either redraw of computerwin
            if self.sets:   #If there are SETs available, computer wins the round
                if self.n <=1: #Dan worden de sets in kaarten gegeven
                    SETfound(self.GetCoords(self.sets[0]),"Computer") #Dus moeten ze nog naar coördinaten
                else: #Ze worden gegeven in coördinaten
                    SETfound(self.GetCoords(self.sets[0]),"Computer")
            else:           #Otherwise, redraw the top cards
                self.Redraw()
        elif Coords == None:
            #If the player input is that there is no SET available
            if self.sets:       #And there IS one, computer wins the round
                print("Wrong: There is a set;",end=" ")
                if self.n<= 1:      #Dan staan ze nog niet in coördinaten
                    SETfound(self.GetCoords(self.sets[0]),"Computer") 
                else:          #En anders al wel
                    SETfound(self.GetCoords(self.sets[0]),"Computer")
            else:              #Otherwise, redraw the top cards
                print("Correct:",end=" ")
                self.Redraw()
        else:
            #If the player gives a Set: *valid* coordinates for the *right amount* of *different* cards
            Cards = []
            for Loc in Coords:
                Cards.append(self.tafel[int(Loc[0])][int(Loc[1])])
            if self.isnset(Cards,self.n):   #Check if those cards actually form a SET
                print("Well done!",end=" ")
                SETfound(Coords,"Player")
            else:                   #The Cards the player gave are no SET, just a Set
                print("These cards are not a SET.",end=" ")
                if self.sets:       #If there are actual SETS available, the computer wins the round
                    if self.n <= 1:
                        SETfound(self.GetCoords(self.sets[0]),"Computer")
                    else:
                        SETfound(self.GetCoords(self.sets[0]),"Computer")
                else:               #Redraw if no SETs present, even if the player input was otherwise
                    self.Redraw()
    
    def Redraw(self,Coords=None):
        """ Called with Set == None only if there are NO SETs
            otherwise the entered coordinates is an already validated SET."""
        def Rearrange(Coords=[]):
            table = [kaart for row in self.tafel for kaart in row]

            for Loc in Coords:
                table.remove(self.tafel[int(Loc[0])][int(Loc[1])])
            self.tafel = []         #We maken eerst de tafel leeg
            newrows = len(table)//self.free
            for j in range(newrows): #We voegen eerst de helemaal gevulde rijen toe
                Row = []
                for i in range(self.free):
                    Row.append(table.pop(0))
                self.tafel.append(Row)
            Row = []
            for i in range(len(table)): #Voeg daarna de resterende kaarten toe aan de laatste rij
                Row.append(table.pop(0))
            for i in range(len(table),self.free): #En wat lege kaarten zodat het printen goed gaat
                Row.append(Kaart([-1,-1,-1,-1],self.dim,self.free))
            self.tafel.append(Row)      #En voeg deze toe aan de tafel
            
        if not Coords:         #If there are no Coordinates given; there is no SET
            print("There is no SET,",end=" ")
            if self.deck:       #If the deck is not empty; redraw the top cards
                print("redrawing the top {} cards".format(self.free))
                Placeholder = [self.tafel[0][i] for i in range(self.free)]
                self.Redraw([[0,i] for i in range(self.free)])
                self.deck.extend(Placeholder)
                random.shuffle(self.deck)
                return
        elif self.deck:         #Coordinates are given of the cards to be replaced
            #Komt niet meer mooi uit met n-set omdat de setgrootte niet persee deckgrootte deelt
            if len(self.deck)>= self.Setgrootte():  #Als er genoeg kaarten zijn
                for Loc in Coords:
                    self.tafel[int(Loc[0])][int(Loc[1])] = self.deck.pop(0)
            else:                                   #Als er niet meer genoeg kaarten zijn
                if self.n == 1:                     #Met 1-set komt het altijd uit
                    Rearrange(Coords)
                else:
                    lengte = len(self.deck)
                    for i in range(lengte):             #leg de resterende kaarten op tafel
                        self.tafel[int(Coords[i][0])][int(Coords[i][1])] = self.deck.pop(0)
                    Rest = []                           #En rearrange met de andere kaarten 
                    for i in range(lengte,self.Setgrootte()): #(die nog niet weggehaalt zijn)
                        Rest.append(Coords[i])
                    Rearrange(Rest)
        else:                   #If the deck is empty, remove the given Set and rearrange
            Rearrange(Coords)
        self.findnsets()
        if self.sets or self.deck:
            self.showtable()
        else:
            print("There is no SET,",end=" ")
            Rearrange()
        
    def Endgame(self):
        print("and the deck is empty: Game Over")
        print("Final Score: Player {} vs Computer {}"
              .format(self.Player["Score"],self.Computer["Score"]))
        if self.Player["Score"] > self.Computer["Score"]:
            print("Congratulations, you have won! Let's play another time!")
            self.Player["Gamewins"] += 1
        elif self.Player["Score"] < self.Computer["Score"]:
            print("Too bad, you lost to the Computer, better luck next time.")
            self.Computer["Gamewins"] += 1
        else:
            print("The Game ended in a tie, maybe you'll win next time?")
            
    def Restart(self):
        Diff = self.Player["Gamewins"]-self.Computer["Gamewins"]
        print("\n","Reinitializing Game,",end=" ")
        if Diff > 0:
            print("Player is leading by {} game".format(Diff),end="")
            if Diff > 1:
                print("s")
            else:
                print("")
        elif Diff < 0:
            print("Computer is leading by {} game".format(-Diff),end="")
            if Diff < -1:
                print("s")
            else:
                print("")
        else:
            print("the match is currently tied")
        for i in range(len(self.tafel)):
            for X in range(len(self.tafel[0])):
                self.deck.append(self.tafel[0].pop())
            self.tafel.remove(self.tafel[0])
        self.deck.extend(self.Player["Cards"])
        self.deck.extend(self.Computer["Cards"])
        random.shuffle(self.deck)
        self.Player["Score"] = 0
        self.Player["Cards"] = []
        self.Computer["Score"] = 0
        self.Computer["Cards"] = []
        self.tafel = [[self.deck.pop(0) for i in range(self.free)] for j in range(self.dim)]
        self.showtable(False)



"""
d = int(input('How many dimensions do you want to play with? (Normal is 4) '))
f = int(input('How many degrees of freedom do you want to play with? (Normal is 3) '))
time = int(input('How many seconds till a timeout? '))
n = int(input('How many n-SET do you want to play? (Normal is 1) '))

if d <= 4 and f == 3:
    Soortinput = input('Do you want to play with coördinates (enter 0) or the keyboard( enter 1)? ')
    Soortinput = int(Soortinput)

if Soortinput == 0:
    print('You are playing with coördinates')
    Normalgame = SET(d,f,n)
    while Normalgame.deck or Normalgame.sets:   #As the deck is not empty or there are sets:
        Normalgame.Playround(time)                  #Keep playing rounds
    Normalgame.Endgame() #Else, end the game

if Soortinput == 1:
    print('You are playing with the keyboard')
    Normalgame = SET(d,f,n)
    while Normalgame.deck or Normalgame.sets:
        Normalgame.Playround2(time)
    Normalgame.Endgame()



"""
#Use this code to have the computer play an automated game
Normalgame = SET(4,3,2)
"""
while Normalgame.deck:
    Normalgame.Endround(None)  #This lets the computer win the automated game
    #if Normalgame.sets:         #This lets the player win the automated game
        #Normalgame.Endround(Normalgame.sets[0])
    #else:
        #Normalgame.Endround(None)
while Normalgame.sets:
    Normalgame.Playround2(120)
Normalgame.Endgame()
"""